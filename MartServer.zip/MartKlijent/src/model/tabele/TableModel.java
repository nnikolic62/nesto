/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.tabele;

import domen.Izdanje;
import domen.Vest;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author User
 */
public class TableModel extends AbstractTableModel{
    
    Izdanje izdanje;
    String[] columnNames = {"Publikacija", "RB", "Naslov", "Tekst"};

    public TableModel() {
        izdanje = new Izdanje();
    }

    

    @Override
    public int getRowCount() {
        return izdanje.getVesti().size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Vest v = izdanje.getVesti().get(rowIndex);
        
        switch(columnIndex){
            case 0:
                return v.getIzdanje().getPublikacija();
            case 1:
                return v.getRB();
            case 2:
                return v.getNaslov();
            case 3:
                return v.getTekst();
            default:
                return "n/a";
        }
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Vest v = izdanje.getVesti().get(rowIndex);
        
        switch(columnIndex){
            case 2:
                v.setNaslov((String) aValue);
                break;
            case 3:
                v.setTekst((String) aValue);
                break;
        }
    }
    
    

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    public void dodaj(Vest v) {
        izdanje.getVesti().add(v);
        fireTableDataChanged();
    }

    public void obrisi(int red) {
        izdanje.getVesti().remove(red);
        fireTableDataChanged();
    }

    public List<Vest> vratiSve() {
        return izdanje.getVesti();
    }
    
    public int vratiRB(){
        int broj = izdanje.getVesti().size();
        return broj + 1;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
    
    
    
    
    
}
