/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niti;

import domen.Izdanje;
import domen.Publikacija;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import komunikacija.KlijentskiZahtev;
import komunikacija.ServerskiOdgovor;
import kontroler.Kontroler;

/**
 *
 * @author User
 */
public class ObradiKlijentaNit extends Thread{
    Socket s;

    public ObradiKlijentaNit(Socket s) {
        this.s = s;
    }

    @Override
    public void run() {
        while(true){
            KlijentskiZahtev kz = prihvatiZahtev();
            ServerskiOdgovor so = new ServerskiOdgovor();
            
            try{
                switch(kz.getOperacija()){
                    case VRATI_PUBLIKACIJE:
                        List<Publikacija> list = Kontroler.getInstance().vratiPublikacije();
                        so.setRezultat(list);
                        break;
                    case VRATI_IZDANJA:
                        List<Izdanje> listI = Kontroler.getInstance().vratiIzdanja();
                        so.setRezultat(listI);
                        break;
                    case SACUVAJ:
                        Izdanje i = (Izdanje) kz.getArgument();
                        boolean rez = Kontroler.getInstance().unesiIzdanje(i);
                        so.setRezultat(rez);
                        break;
                }
                posaljiOdgovor(so);
            } catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }

    private KlijentskiZahtev prihvatiZahtev() {
        try {
            ObjectInputStream in = new ObjectInputStream(s.getInputStream());
            return (KlijentskiZahtev) in.readObject();
        } catch (IOException ex) {
            Logger.getLogger(ObradiKlijentaNit.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ObradiKlijentaNit.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private void posaljiOdgovor(ServerskiOdgovor so) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(so);
            out.flush();
        } catch (IOException ex) {
            Logger.getLogger(ObradiKlijentaNit.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
