/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import db.DBBroker;
import domen.Izdanje;
import domen.Publikacija;
import java.util.List;

/**
 *
 * @author User
 */
public class Kontroler {
    private static Kontroler instance;
    DBBroker db;

    public Kontroler() {
        db = new DBBroker();
    }
    
    public static Kontroler getInstance(){
        if(instance == null)
            instance = new Kontroler();
        return instance;
    }

    public List<Publikacija> vratiPublikacije() {
        List<Publikacija> list = null;
        db.ucitajDrajver();
        db.otvoriKonekciju();
        try {
            list = db.vratiPublikacije();
            System.out.println(list.size());
            db.commit();
        } catch (Exception e) {
            db.rollback();
        } finally{
            db.zatvoriKonekciju();
        }
        return list;
    }

    public List<Izdanje> vratiIzdanja() {
        List<Izdanje> list = null;
        db.ucitajDrajver();
        db.otvoriKonekciju();
        try {
            list = db.vratiSvaIzdanja();
            System.out.println(list.size());
            db.commit();
        } catch (Exception e) {
            db.rollback();
        } finally{
            db.zatvoriKonekciju();
        }
        return list;
    }

    public boolean unesiIzdanje(Izdanje i) {
        db.ucitajDrajver();
        db.otvoriKonekciju();
        try {
            db.unesiDatoIzdanje(i);
            db.commit();
            System.out.println("uneto");
            return true;
        } catch (Exception e) {
            System.out.println("ne");
            db.rollback();
        } finally{
            db.zatvoriKonekciju();
        }
        return false;
    }
    
    
}
