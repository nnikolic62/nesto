/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import domen.Izdanje;
import domen.Publikacija;
import domen.Vest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class DBBroker {

    Connection connection;

    public void ucitajDrajver() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void otvoriKonekciju() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ispitmart", "root", "");
            connection.setAutoCommit(false);
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void zatvoriKonekciju() {
        try {
            connection.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void commit() {
        try {
            connection.commit();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void rollback() {
        try {
            connection.rollback();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<Publikacija> vratiPublikacije() throws SQLException {
        String sql = "SELECT * FROM publikacija";
        List<Publikacija> list = new ArrayList<>();
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Publikacija p = new Publikacija(rs.getInt("publikacijaID"), rs.getString("naziv"));
            list.add(p);
        }
        rs.close();
        st.close();
        return list;
    }

    public List<Izdanje> vratiSvaIzdanja() throws SQLException {
        String sql = "SELECT * FROM izdanje i join publikacija p on i.publikacijaID = p.publikacijaID";
        List<Izdanje> list = new ArrayList<>();
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            Publikacija p = new Publikacija(rs.getInt("publikacijaID"), rs.getString("naziv"));
            Izdanje i = new Izdanje(rs.getInt("izdanjeID"), new java.sql.Date(rs.getDate("datum").getTime()), rs.getInt("broj"), p);
            list.add(i);
        }
        rs.close();
        st.close();
        return list;
    }

    public void unesiDatoIzdanje(Izdanje i) {
        try {
            String sql = "INSERT INTO izdanje (datum, broj, publikacijaID) VALUES (?,?,?)";
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setDate(1, new java.sql.Date(i.getDatum().getTime()));
            ps.setInt(2, i.getBroj());
            ps.setInt(3, i.getPublikacija().getPublikacijaID());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();

            if (rs.next()) {
                int id = rs.getInt(1);
                i.setIzdanjeID(id);

                sql = "INSERT INTO vest VALUES (?,?,?,?)";
                ps = connection.prepareStatement(sql);
                for (Vest vest : i.getVesti()) {
                    ps.setInt(1, i.getIzdanjeID());
                    ps.setInt(2, vest.getRB());
                    ps.setString(3, vest.getNaslov());
                    ps.setString(4, vest.getTekst());
                    ps.executeUpdate();
                }
            } else {
                throw new Exception("GRESKA U SQL");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
