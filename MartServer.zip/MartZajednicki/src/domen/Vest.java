/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class Vest implements Serializable{
    Izdanje izdanje;
    int RB;
    String naslov;
    String tekst;

    public Vest() {
    }

    public Vest(Izdanje izdanje, int RB, String naslov, String tekst) {
        this.izdanje = izdanje;
        this.RB = RB;
        this.naslov = naslov;
        this.tekst = tekst;
    }
    
    

    public Izdanje getIzdanje() {
        return izdanje;
    }

    public void setIzdanje(Izdanje izdanje) {
        this.izdanje = izdanje;
    }

    public int getRB() {
        return RB;
    }

    public void setRB(int RB) {
        this.RB = RB;
    }

    public String getNaslov() {
        return naslov;
    }

    public void setNaslov(String naslov) {
        this.naslov = naslov;
    }

    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }
    
    
}
