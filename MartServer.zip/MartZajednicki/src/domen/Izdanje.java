/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author User
 */
public class Izdanje implements Serializable{
    int izdanjeID;
    Date datum;
    int broj;
    Publikacija publikacija;
    List<Vest> vesti;

    public Izdanje() {
        vesti = new ArrayList<>();
    }

    public Izdanje(int izdanjeID, Date datum, int broj, Publikacija publikacija) {
        this.izdanjeID = izdanjeID;
        this.datum = datum;
        this.broj = broj;
        this.publikacija = publikacija;
    }

    public int getIzdanjeID() {
        return izdanjeID;
    }

    public void setIzdanjeID(int izdanjeID) {
        this.izdanjeID = izdanjeID;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }

    public int getBroj() {
        return broj;
    }

    public void setBroj(int broj) {
        this.broj = broj;
    }

    public Publikacija getPublikacija() {
        return publikacija;
    }

    public void setPublikacija(Publikacija publikacija) {
        this.publikacija = publikacija;
    }

    public List<Vest> getVesti() {
        return vesti;
    }

    public void setVesti(List<Vest> vesti) {
        this.vesti = vesti;
    }
    
    
    
    
}
