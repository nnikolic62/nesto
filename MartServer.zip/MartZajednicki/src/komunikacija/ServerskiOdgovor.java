/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package komunikacija;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class ServerskiOdgovor implements Serializable{
    Object rezultat;
    Exception ex;

    public ServerskiOdgovor() {
    }

    public ServerskiOdgovor(Object rezultat, Exception ex) {
        this.rezultat = rezultat;
        this.ex = ex;
    }

    public Object getRezultat() {
        return rezultat;
    }

    public void setRezultat(Object rezultat) {
        this.rezultat = rezultat;
    }

    public Exception getEx() {
        return ex;
    }

    public void setEx(Exception ex) {
        this.ex = ex;
    }
    
    
}
